EXAMSPRINT — JEE + HSC STUDY TRACKER PWA

WHAT THIS IS
- An installable Progressive Web App (PWA) based on the existing JEE/HSC tracker.
- Includes Home, Syllabus, Today (3rd tab), Boards, Roadmap, Revise, Tests and Journal.
- The first screen asks for the student's name. Each name has a separate local progress profile on that device/browser.
- The app saves progress locally and includes backup export/restore. Each student should export backups regularly.
- Offline caching works after the app has first loaded online from an HTTPS host.

IMPORTANT ABOUT PROFILES AND PRIVACY
- A name is a local profile label, not an online account. It does not sync progress between devices.
- Profiles on the same browser/device are separated for convenience, not secured against someone using browser developer tools.
- To move progress to a new device, use Home > Export backup, then Restore backup on the new device.

HOW TO PUBLISH (OWNER/HOST CONTROLS APP UPDATES)
1. Create a repository in your own GitHub account. Keep the repository private if your plan supports the hosting setup you need; GitHub Pages hosting commonly requires a public repository on free accounts.
2. Upload the contents of this folder (index.html, manifest.webmanifest, sw.js, icons folder) to the repository root.
3. In the repository settings, open Pages and publish from the main branch/root folder.
4. Wait for GitHub Pages to give you the HTTPS site URL. Open that URL in Chrome on Android.
5. In Chrome, use the menu > Add to Home screen / Install app.
6. Share the HTTPS site URL with friends; they can install the same app on their phones.

HOW TO UPDATE LATER
1. Edit index.html (or the other files) and upload/commit the changed files to your hosting repository.
2. IMPORTANT: whenever you change app files, change CACHE_NAME in sw.js from "examsprint-cache-v1" to a new version such as "examsprint-cache-v2". This tells the service worker to refresh cached app files.
3. Open the hosted URL and reload the app. If an old version remains, close the installed app and reopen it or clear that site's cache.
4. Keep backups before substantial changes.

OWNER-ONLY MODIFICATION
- There is intentionally no in-app admin password for editing the app itself. The owner controls published changes through the hosting account/repository. Do not share hosting credentials or repository write access with users who should not publish changes.
- A password typed into a static HTML app cannot securely protect its source code. If later you want shared online data with authenticated admin-only editing, that requires a backend/database and real authentication, which is a separate upgrade.

TESTING NOTES
- JavaScript syntax was checked. This package has not been fully browser-tested on every Android/browser combination.
- Local progress is stored in the browser/device; clearing browser site data can erase it. Export backups.
- The first online load is needed before offline caching can be installed. Service workers require HTTPS (or localhost for development).
